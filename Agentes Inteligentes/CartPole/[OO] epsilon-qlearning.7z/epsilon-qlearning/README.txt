Para executar

$ python3 __main__.py
