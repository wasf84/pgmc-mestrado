# coding: utf-8

try:
    import base.agente as ag
except ImportError:
    raise ImportError("Falha na importação dos módulos.")
# ===================================================================== #
if __name__ == "__main__":

    # Agente treinador, vai gerar a QTable para os demais agentes usarem
    ag_t = ag.Agente(thread_id = 0, ag_name = "Agente Treinador", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 5000, min_epsilon = 0.1, min_learning_rate = 0.2, discount_factor = 0.95, dec = 30, qtable = None)

    # QTable treinada
    qtable_t = ag_t.training()

    ag1 = ag.Agente(thread_id = 1, ag_name = "Agente 1", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 50, min_epsilon = None, min_learning_rate = None, discount_factor = None, dec = None, qtable = qtable_t)

    ag2 = ag.Agente(thread_id = 2, ag_name = "Agente 2", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 500, min_epsilon = None, min_learning_rate = None, discount_factor = None, dec = None, qtable = qtable_t)

    ag3 = ag.Agente(thread_id = 3, ag_name = "Agente 3", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 5000, min_epsilon = None, min_learning_rate = None, discount_factor = None, dec = None, qtable = qtable_t)

    ag4 = ag.Agente(thread_id = 4, ag_name = "Agente 4", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 100, min_epsilon = None, min_learning_rate = None, discount_factor = None, dec = None, qtable = qtable_t)

    ag5 = ag.Agente(thread_id = 5, ag_name = "Agente 5", env_name = "CartPole-v1", discrete = (1, 1, 50, 50),
                    num_eps = 1000, min_epsilon = None, min_learning_rate = None, discount_factor = None, dec = None, qtable = qtable_t)

    ag1.start()
    ag2.start()
    ag3.start()
    ag4.start()
    ag5.start()