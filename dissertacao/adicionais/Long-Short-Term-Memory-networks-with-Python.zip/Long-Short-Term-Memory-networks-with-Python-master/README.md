# Long-Short-Term-Memory-networks-with-Python

This repository contains code from the book "Long short term memory networks with Python" by Dr. Jason Brownlee.
