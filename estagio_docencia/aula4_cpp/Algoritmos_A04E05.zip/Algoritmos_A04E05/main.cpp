#include <iostream>

/**
Fa�a uma fun��o que recebe como par�metros dois n�meros reais e um caractere ('+', '-', '*' ou '/').
Sua fun��o deve imprimir o resultado da opera��o efetuada sobre os n�meros.

Fa�a um programa principal (main) que leia dois n�meros reais e um caractere e chame a fun��o anterior.

Dica: Considere que o segundo n�mero lido nunca ser� zero quando a opera��o selecionada for a opera��o de divis�o.
*/

using namespace std;

void calc(float x, float y, char op) {
    if (op == '+') cout << x << " " << op << " " << y << " = " << x+y << endl;
    else if (op == '-') cout << x << " " << op << " " << y << " = " << x-y << endl;
    else if (op == '*') cout << x << " " << op << " " << y << " = " << x*y << endl;
    else if (op == '/') cout << x << " " << op << " " << y << " = " << x/y << endl;

    return;
}

int main() {
    float _x, _y;
    char _op;

    cin >> _x >> _y;
    cin >> _op;

    calc(_x, _y, _op);

    return 0;
}
