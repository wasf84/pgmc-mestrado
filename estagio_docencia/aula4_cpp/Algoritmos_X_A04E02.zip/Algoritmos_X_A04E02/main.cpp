#include <iostream>

/**
A escola �APRENDER� faz o pagamento de seus professores por hora/aula.
Fa�a uma fun��o que calcule e retorne o sal�rio de um professor.

Sabe-se que o valor da hora/aula segue a tabela abaixo:
Professor N�vel 1 R$12,00 por hora/aula
Professor N�vel 2 R$17,00 por hora/aula
Professor N�vel 3 R$25,00 por hora/aula

Fa�a a leitura do n�vel e o n�mero de horas na "main" e passe por par�metro para a fun��o,
ao final imprima a resposta o valor do sal�rio na fun��o tamb�m na "main" no formato R$9.99,
ou seja precedido por um R$ e com 2 casas decimais.

Caso seja preenchido um n�vel inv�lido considere R$0,00 por hora/aula.
*/

using namespace std;

void calcular_salario(int nivel, float horas) {
    cout.precision(2);
    cout << fixed;

    if (nivel == 1)
        cout << "R$" << horas * 12;
    else if (nivel == 2)
        cout << "R$" << horas * 17;
    else if (nivel == 3)
        cout << "R$" << horas * 25;
    else
        cout << "R$" << horas * 0;

}

int main() {
    int nivel;
    float horas;

    cin >> nivel;
    cin >> horas;

    calcular_salario(nivel, horas);

    return 0;
}
