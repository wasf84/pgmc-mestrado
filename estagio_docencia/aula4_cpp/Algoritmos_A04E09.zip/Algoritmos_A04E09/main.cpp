#include <iostream>

using namespace std;

/**
O dono de um supermercado quer modificar o c�lculo do pre�o final das mercadorias usando como base o seu valor de custo:
    At� R$2,00, o acr�scimo deve ser um valor fixo de R$0,15;
    Entre R$2,00 e R$5,00, o acr�scimo deve ser proporcional, de 2%;
    Entre R$5,00 e R$20,00, deve ser proporcional, de 10%;
    Acima de R$20,00, o acr�scimo deve ser proporcional, de 8%.
    Assim, um produto que custe R$ 28,00, ter� acr�scimo de R$ 2,35, calculado da seguinte forma:

    R$ 0,15 => referente aos primeiros R$ 2,00;
    + R$ 0,06 => referente aos 2% sobre a faixa R$ 2,00 a R$ 5,00 (R$ 3);
    + R$ 1,50 => referente aos 10% sobre a faixa R$ 5,00 a R$ 20,00 (R$ 15);
    + R$ 0,64 => referente aos 8% acima de R$ 20,00 (R$ 8).

Fa�a um programa que leia o valor de custo do produto e imprima o seu pre�o final.
*/

void gerarPrecoFinal(float p) {
    float prc_final = 0;

    if (p <= 0) cout << "Pre�o de custo N�O pode ser ZERO ou NEGATIVO." << endl;
    else if (p > 0 && p <= 2)  prc_final = (p + 0.15);
    else if (p > 2 && p <= 5)  prc_final = (p + 0.15) + ((p - 2) * 0.02);
    else if (p > 5 && p <= 20) prc_final = (p + 0.15) + (3 * 0.02) + ((p - 5) * 0.10);
    else prc_final = (p + 0.15) + (3 * 0.02) + (15 * 0.10) + ((p - 20) * 0.08);

    cout << "Preco final: R$ " << prc_final << " (acrescimo de R$ " << (prc_final - p) << ")" << endl;

    return;

}

int main() {
    float _p;

    cin >> _p;

    gerarPrecoFinal(_p);
    return 0;
}
