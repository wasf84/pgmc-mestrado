#include <iostream>

using namespace std;

/**
Escreva uma fun��o que receba como par�metros quatro n�meros inteiros (A, B, C e D)
    e retorne o valor 0 se os n�meros digitados s�o v�lidos ou o valor 1 caso sejam inv�lidos.
    Eles ser�o v�lidos se TODAS as seguintes condi��es s�o satisfeitas:
    (a) B for maior que C;
    (b) D for maior que A;
    (c) a soma de C com D for maior que a soma de A com B;
    (d) C e D forem valores positivos; e
    (e) A � um n�mero par.

Escreva uma fun��o principal (main) que leia quatro valores inteiros digitados pelo usu�rio,
    chame a fun��o anterior e imprima a mensagem "Valores aceitos" ou "Valores nao aceitos"
    de acordo com o retorno da fun��o.
*/

int verificar(int a, int b, int c, int d) {
    int saida = 1;

    if (b > c)
        if (d > a)
            if ((c + d) > (a + b))
                if (c > 0 && d > 0)
                    if (a % 2 == 0)
                        saida = 0;

    return saida;
}

int main() {
    int _a, _b, _c, _d;

    cin >> _a;
    cin >> _b;
    cin >> _c;
    cin >> _d;

    if (verificar(_a, _b, _c, _d) == 0)
        cout << "Valores aceitos" << endl;
    else
        cout << "Valores nao aceitos" << endl;

    return 0;
}
