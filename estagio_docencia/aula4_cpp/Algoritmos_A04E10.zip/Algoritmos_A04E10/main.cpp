#include <iostream>

using namespace std;

/**
Escreva uma fun��o que receba como par�metros tr�s n�meros inteiros e retorne o maior n�mero.

Escreva uma fun��o principal (main) que leia tr�s valores inteiros digitados pelo usu�rio,
chame a fun��o anterior e imprima o maior inteiro informado.
*/

void maior(int a, int b, int c) {
    int _max = a;
    if (b > _max) _max = b;
    if (c > _max) _max = c;

    cout << "O maior valor digitado pelo usuario foi " << _max << "."<< endl;

    return;
}

int main() {
    int _a, _b, _c;

    cin >> _a;
    cin >> _b;
    cin >> _c;

    maior(_a, _b, _c);

    return 0;
}
