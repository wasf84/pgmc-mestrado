#include <iostream>

/**
Para resolver este exerc�cio, siga os passos abaixo:
    Escreva uma fun��o que receba como par�metro dois n�meros inteiros e imprima se um � divis�vel por outro.
    Escreva uma fun��o principal (main) que leia do teclado um n�mero inteiro
        e chame a fun��o desenvolvida no item anterior para verificar se este n�mero � divis�vel por 2, 3, 5 e 7.

Dica: Observe que a fun��o poder� ser chamada mais de uma vez.
*/

using namespace std;

void verificar(int a, int b) {
    if (a % b == 0) cout << a << " � divis�vel por " << b << endl;
    else cout << a << " n�o � divis�vel por " << b << endl;

    return;
}

int main() {
    int _a;

    cin >> _a;

    verificar(_a, 2);
    verificar(_a, 3);
    verificar(_a, 5);
    verificar(_a, 7);

    return 0;
}
