#include <iostream>

/**
Fa�a uma fun��o que receba como par�metro  dois n�meros reais e um caractere: ' + ', ' - ', ' * ' ou ' / '.
A fun��o deve imprimir o resultado da opera��o efetuada sobre os n�meros lidos.

Lembre-se que divis�o por 0 n�o existe, portanto imprima a mensagem "ERRO: Divisao por Zero"
    caso n�o seja poss�vel efetuar um c�lculo.

Fa�a tamb�m um programa (main) para ler o caractere e os n�meros e chamar a fun��o feita.
*/

using namespace std;

void op(char o, float a, float b) {
    cout.precision(4);
    cout << fixed;

    if (o == '+')
        cout << a+b;
    else if (o == '-')
        cout << a-b;
    else if (o == '*')
        cout << a*b;
    else {
        if (b == 0)
            cout << "ERRO: Divisao por Zero";
        else
            cout << a/b;
    }

    return;
}

int main() {
    char _o;
    float _a, _b;

    cin >> _o;
    cin >> _a;
    cin >> _b;

    op(_o, _a, _b);

    return 0;
}
