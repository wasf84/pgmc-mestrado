#include <iostream>

/**
Escrever uma fun��o que leia a matr�cula e as tr�s notas obtidas por um aluno durante o semestre.
Calcular a sua m�dia (aritm�tica), imprimir a matr�cula e sua situa��o, sendo "Aprovado" (media >= 7),
    "Reprovado" (media <= 5) ou "Recuperacao" (5 < media < 7).
O programa para chamar a fun��o j� est� implementado a seguir, implemente apenas a fun��o.
*/

using namespace std;

void avaliar() {
    int mat;
    float na, nb, nc;

    cin >> mat;
    cin >> na;
    cin >> nb;
    cin >> nc;

    if ((na + nb + nc) / 3 >= 7)
        cout << mat << " Aprovado" << endl;
    else if ((na + nb + nc) / 3 <= 5)
        cout << mat << " Reprovado" << endl;
    else
        cout << mat << " Recuperacao" << endl;

    return;
}

int main(){
    avaliar();

    return 0;
}
