#include <iostream>

/**
Para resolver este exerc�cio, siga os passos abaixo:
    Escreva uma fun��o que receba como par�metro um inteiro (dia da semana) e imprima o seu nome por extenso.
    Considere que o n�mero 1 representa o domingo; 2 a segunda-feira, etc. Caso o n�mero n�o corresponda a um dia da semana,
    a fun��o deve exibir a mensagem "Dia da semana inv�lido!".

    Escreva uma fun��o principal (main) que leia do teclado um n�mero inteiro e chame a fun��o desenvolvida no item anterior.
*/

using namespace std;

void imprimirDiaDaSemana(int d) {
    switch (d) {
        case 1: cout << "Domingo!"       << endl; break;
        case 2: cout << "Segunda-feira!" << endl; break;
        case 3: cout << "Ter�a-feira!"   << endl; break;
        case 4: cout << "Quarta-feira!"  << endl; break;
        case 5: cout << "Quinta-feira!"  << endl; break;
        case 6: cout << "Sexta-feira!"   << endl; break;
        case 7: cout << "S�bado!"        << endl; break;

        default: cout << "Dia da semana inv�lido!" << endl;
    }
}

int main() {
    int _d;

    cin >> _d;

    imprimirDiaDaSemana(_d);
    return 0;
}
