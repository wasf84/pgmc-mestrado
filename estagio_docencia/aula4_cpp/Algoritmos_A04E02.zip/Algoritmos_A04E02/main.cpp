#include <iostream>

/**
Para resolver este exerc�cio, siga os passos abaixo:
    Escreva uma fun��o que receba como par�metro um n�mero inteiro e imprima na tela se este n�mero � par ou �mpar.
    Escreva uma fun��o principal (main) que leia do teclado um n�mero inteiro
        e chame a fun��o desenvolvida no item anterior.
*/

using namespace std;

void verificar(int n) {
    if (n % 2 == 0) cout << "O n�mero " << n << " � par!" << endl;
    else cout << "O n�mero " << n << " � �mpar!" << endl;

    return;
}

int main() {
    int _n;

    cin >> _n;

    verificar(_n);

    return 0;
}
