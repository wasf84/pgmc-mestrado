#include <iostream>

/**
Para resolver este exercício, siga os passos abaixo:
    Escreva uma função que receba como parâmetro a idade de uma pessoa (inteiro) e imprima:
    "Criança", se idade < 13;
    "Adolescente", se 13 ≤ idade < 20;
    "Adulto", se 20 ≤ idade < 65;
    "Idoso", se idade ≥ 65.

    Escreva também uma função principal (main) que leia do teclado uma idade e chame a função desenvolvida no item anterior.
*/

using namespace std;

void verificarIdade(int i) {
    if (i < 13) cout << "Criança" << endl;
    else if (i >= 13 && i < 20) cout << "Adolescente" << endl;
    else if (i >= 20 && i < 65) cout << "Adulto" << endl;
    else cout << "Idoso" << endl;
}

int main() {
    int _i;

    cin >> _i;

    verificarIdade(_i);

    return 0;
}
