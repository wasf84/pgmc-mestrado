#include <iostream>

using namespace std;

/*
Faça um programa que leia a altura e o diâmetro de um copo e imprima na tela o seu volume. Considere para este exercício que pi = 3.141592.

Dica: O volume de um cilindro é dado por:

V = pi * r^2 * h

onde 'r' é o raio e 'h' é a altura do cilindro.
*/

#define PI 3.141592

double calcularVolume(double r, double h) {
    return (PI * (r*r) * h);
}

int main() {
    double _h, _d;

    cout << "Digite a altura...: ";
    cin >> _h;
    cout << endl;

    cout << "Digite o diametro...: ";
    cin >> _d;
    cout << endl;

    cout << "Volume do copo...: " << calcularVolume(_d/2.0, _h) << " cm3" << endl;

    return 0;
}
