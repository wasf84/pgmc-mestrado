#include <iostream>

using namespace std;

/**
    Fa�a um programa que leia uma temperatura em graus Celsius e apresente-a convertida em graus Fahrenheit. A f�rmula de convers�o �: F = (9.0*C + 160.0)/5.0.
*/

void converterTemperatura(double t) {
    cout.precision(3);
    cout << "Fahrenheit(F)...: " << (9.0*t + 160.0)/5.0 << endl;
    return;
}


int main() {
    double _t;

    cout << "Celsius(C)...: ";
    cin.precision(3);
    cin >> _t;
    converterTemperatura(_t);

    return 0;
}
